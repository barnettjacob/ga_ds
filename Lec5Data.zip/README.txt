The data provided here is intendent to be use only within the context of 
the GA Data Science lectures.
Dr J Rogel-Salazar